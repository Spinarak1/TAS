package com.packt.project1.controller;
import org.springframework.data.repository.CrudRepository;

interface UslugaRepository extends CrudRepository<Usluga, Integer> {
}